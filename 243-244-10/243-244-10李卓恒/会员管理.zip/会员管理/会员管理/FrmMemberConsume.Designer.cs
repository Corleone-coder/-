﻿namespace SupermarketSalesSystem.UI
{
    partial class FrmMemberConsume
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        private void InitializeComponent()
        {
            this.gbQuery = new System.Windows.Forms.GroupBox();
            this.btnQuery = new System.Windows.Forms.Button();
            this.txtMemberCard = new System.Windows.Forms.TextBox();
            this.lblMemberCard = new System.Windows.Forms.Label();
            this.dgvConsumeList = new System.Windows.Forms.DataGridView();
            this.gbQuery.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConsumeList)).BeginInit();
            this.SuspendLayout();
            // 
            // gbQuery
            // 
            this.gbQuery.Controls.Add(this.btnQuery);
            this.gbQuery.Controls.Add(this.txtMemberCard);
            this.gbQuery.Controls.Add(this.lblMemberCard);
            this.gbQuery.Location = new System.Drawing.Point(12, 12);
            this.gbQuery.Name = "gbQuery";
            this.gbQuery.Size = new System.Drawing.Size(800, 60);
            this.gbQuery.TabIndex = 0;
            this.gbQuery.TabStop = false;
            this.gbQuery.Text = "消费记录查询";
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(250, 20);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 23);
            this.btnQuery.TabIndex = 2;
            this.btnQuery.Text = "查询";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // txtMemberCard
            // 
            this.txtMemberCard.Location = new System.Drawing.Point(89, 22);
            this.txtMemberCard.Name = "txtMemberCard";
            this.txtMemberCard.Size = new System.Drawing.Size(150, 21);
            this.txtMemberCard.TabIndex = 1;
            // 
            // lblMemberCard
            // 
            this.lblMemberCard.AutoSize = true;
            this.lblMemberCard.Location = new System.Drawing.Point(20, 25);
            this.lblMemberCard.Name = "lblMemberCard";
            this.lblMemberCard.Size = new System.Drawing.Size(65, 12);
            this.lblMemberCard.TabIndex = 0;
            this.lblMemberCard.Text = "会员卡号：";
            // 
            // dgvConsumeList
            // 
            this.dgvConsumeList.AllowUserToAddRows = false;
            this.dgvConsumeList.AllowUserToDeleteRows = false;
            this.dgvConsumeList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvConsumeList.Location = new System.Drawing.Point(12, 78);
            this.dgvConsumeList.Name = "dgvConsumeList";
            this.dgvConsumeList.ReadOnly = true;
            this.dgvConsumeList.RowTemplate.Height = 23;
            this.dgvConsumeList.Size = new System.Drawing.Size(800, 400);
            this.dgvConsumeList.TabIndex = 1;
            // 
            // FrmMemberConsume
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 490);
            this.Controls.Add(this.dgvConsumeList);
            this.Controls.Add(this.gbQuery);
            this.Name = "FrmMemberConsume";
            this.Text = "会员消费记录查询";
            this.gbQuery.ResumeLayout(false);
            this.gbQuery.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConsumeList)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox gbQuery;
        private System.Windows.Forms.Button btnQuery;
        internal System.Windows.Forms.TextBox txtMemberCard;
        private System.Windows.Forms.Label lblMemberCard;
        private System.Windows.Forms.DataGridView dgvConsumeList;
    }
}