﻿using System;

namespace SupermarketSalesSystem.Models
{
    /// <summary>
    /// 会员等级实体（对应member_level表）
    /// </summary>
    public class MemberLevel
    {
        public string LevelId { get; set; }
        public string LevelName { get; set; }
        public int UpgradePoints { get; set; }
        public decimal UpgradeConsume { get; set; }
        public decimal DiscountRate { get; set; }
        public string LevelDesc { get; set; }
    }

    /// <summary>
    /// 会员实体（对应member表）
    /// </summary>
    public class Member
    {
        public string MemberId { get; set; }
        public string MemberCard { get; set; }
        public string MemberName { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string LevelId { get; set; }
        public decimal TotalConsume { get; set; }
        public int TotalPoints { get; set; }
        public int Status { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime UpdateTime { get; set; }

        // 扩展：关联会员等级名称（方便界面显示）
        public string LevelName { get; set; }
        // 状态名称（1-正常，0-注销）
        public string StatusName => Status == 1 ? "正常" : "注销";
    }
}