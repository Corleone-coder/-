﻿using System;

namespace SupermarketSalesSystem.Models
{
    /// <summary>
    /// 订单主表实体（对应order_main表）
    /// </summary>
    public class OrderMain
    {
        public string OrderId { get; set; }
        public string MemberId { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal ActualAmount { get; set; }
        public int PayType { get; set; }
        public int OrderStatus { get; set; }
        public string CashierId { get; set; }
        public DateTime OrderTime { get; set; }
        public DateTime? PayTime { get; set; }
        public string Remark { get; set; }

        // 扩展字段
        public string MemberCard { get; set; } // 会员卡号
        public string MemberName { get; set; } // 会员姓名
        public string CashierName { get; set; } // 收银员姓名
                                                // 替换PayTypeName
        public string PayTypeName
        {
            get
            {
                switch (PayType)
                {
                    case 1: return "现金";
                    case 2: return "银行卡";
                    case 3: return "赠券";
                    default: return "未知";
                }
            }
        }

        // 替换OrderStatusName
        public string OrderStatusName
        {
            get
            {
                switch (OrderStatus)
                {
                    case 0: return "待结账";
                    case 1: return "已完成";
                    case 2: return "挂单中";
                    case 3: return "已撤销";
                    case 4: return "已整单退货";
                    case 5: return "部分退货";
                    default: return "未知";
                }
            }
        }
    }

    /// <summary>
    /// 积分兑换实体
    /// </summary>
    public class PointsExchange
    {
        public string MemberId { get; set; }
        public int ExchangePoints { get; set; } // 兑换积分
        public decimal ExchangeAmount { get; set; } // 兑换金额（如100积分=1元）
        public DateTime ExchangeTime { get; set; }
        public string HandlerId { get; set; } // 操作人ID
    }
}