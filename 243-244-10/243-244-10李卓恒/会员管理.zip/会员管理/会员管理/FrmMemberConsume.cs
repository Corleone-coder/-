﻿using SupermarketSalesSystem.DAL;
using System;
using System.Data;
using System.Windows.Forms;

namespace SupermarketSalesSystem.UI
{
    public partial class FrmMemberConsume : Form
    {
        private readonly OrderDal _orderDal = new OrderDal();

        public FrmMemberConsume()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 查询消费记录
        /// </summary>
        private void btnQuery_Click(object sender, EventArgs e)
        {
            string memberCard = txtMemberCard.Text.Trim();
            if (string.IsNullOrEmpty(memberCard))
            {
                MessageBox.Show("请输入会员卡号！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataTable dt = _orderDal.GetConsumeRecordsByMemberCard(memberCard);
            dgvConsumeList.DataSource = dt;
            SetDgvColumnNames();
        }

        /// <summary>
        /// 设置DataGridView列名
        /// </summary>
        private void SetDgvColumnNames()
        {
            if (dgvConsumeList.Columns["order_id"] != null)
                dgvConsumeList.Columns["order_id"].HeaderText = "订单ID";
            if (dgvConsumeList.Columns["member_card"] != null)
                dgvConsumeList.Columns["member_card"].HeaderText = "会员卡号";
            if (dgvConsumeList.Columns["member_name"] != null)
                dgvConsumeList.Columns["member_name"].HeaderText = "会员姓名";
            if (dgvConsumeList.Columns["total_amount"] != null)
                dgvConsumeList.Columns["total_amount"].HeaderText = "订单总金额";
            if (dgvConsumeList.Columns["actual_amount"] != null)
                dgvConsumeList.Columns["actual_amount"].HeaderText = "实付金额";
            if (dgvConsumeList.Columns["PayTypeName"] != null)
                dgvConsumeList.Columns["PayTypeName"].HeaderText = "支付方式";
            if (dgvConsumeList.Columns["cashier_name"] != null)
                dgvConsumeList.Columns["cashier_name"].HeaderText = "收银员";
            if (dgvConsumeList.Columns["order_time"] != null)
                dgvConsumeList.Columns["order_time"].HeaderText = "消费时间";
            if (dgvConsumeList.Columns["OrderStatusName"] != null)
                dgvConsumeList.Columns["OrderStatusName"].HeaderText = "订单状态";

            // 隐藏无关列
            if (dgvConsumeList.Columns["member_id"] != null)
                dgvConsumeList.Columns["member_id"].Visible = false;
            if (dgvConsumeList.Columns["cashier_id"] != null)
                dgvConsumeList.Columns["cashier_id"].Visible = false;
        }
    }
}