﻿namespace SupermarketSalesSystem.UI
{
    partial class FrmMemberManager
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        private void InitializeComponent()
        {
            this.gbQuery = new System.Windows.Forms.GroupBox();
            this.btnQuery = new System.Windows.Forms.Button();
            this.txtMemberCard = new System.Windows.Forms.TextBox();
            this.lblMemberCard = new System.Windows.Forms.Label();
            this.dgvMemberList = new System.Windows.Forms.DataGridView();
            this.gbEdit = new System.Windows.Forms.GroupBox();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtTotalPoints = new System.Windows.Forms.TextBox();
            this.lblTotalPoints = new System.Windows.Forms.Label();
            this.txtTotalConsume = new System.Windows.Forms.TextBox();
            this.lblTotalConsume = new System.Windows.Forms.Label();
            this.cmbLevel = new System.Windows.Forms.ComboBox();
            this.lblLevel = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtMemberName = new System.Windows.Forms.TextBox();
            this.lblMemberName = new System.Windows.Forms.Label();
            this.txtMemberCardEdit = new System.Windows.Forms.TextBox();
            this.lblMemberCardEdit = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnExchange = new System.Windows.Forms.Button();
            this.btnUpgrade = new System.Windows.Forms.Button();
            this.btnConsume = new System.Windows.Forms.Button();
            this.gbQuery.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMemberList)).BeginInit();
            this.gbEdit.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbQuery
            // 
            this.gbQuery.Controls.Add(this.btnQuery);
            this.gbQuery.Controls.Add(this.txtMemberCard);
            this.gbQuery.Controls.Add(this.lblMemberCard);
            this.gbQuery.Location = new System.Drawing.Point(16, 15);
            this.gbQuery.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbQuery.Name = "gbQuery";
            this.gbQuery.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbQuery.Size = new System.Drawing.Size(1067, 75);
            this.gbQuery.TabIndex = 0;
            this.gbQuery.TabStop = false;
            this.gbQuery.Text = "查询条件";
            this.gbQuery.Enter += new System.EventHandler(this.gbQuery_Enter);
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(333, 25);
            this.btnQuery.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(100, 29);
            this.btnQuery.TabIndex = 2;
            this.btnQuery.Text = "查询";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // txtMemberCard
            // 
            this.txtMemberCard.Location = new System.Drawing.Point(119, 28);
            this.txtMemberCard.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMemberCard.Name = "txtMemberCard";
            this.txtMemberCard.Size = new System.Drawing.Size(199, 25);
            this.txtMemberCard.TabIndex = 1;
            // 
            // lblMemberCard
            // 
            this.lblMemberCard.AutoSize = true;
            this.lblMemberCard.Location = new System.Drawing.Point(27, 31);
            this.lblMemberCard.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMemberCard.Name = "lblMemberCard";
            this.lblMemberCard.Size = new System.Drawing.Size(82, 15);
            this.lblMemberCard.TabIndex = 0;
            this.lblMemberCard.Text = "会员卡号：";
            // 
            // dgvMemberList
            // 
            this.dgvMemberList.AllowUserToAddRows = false;
            this.dgvMemberList.AllowUserToDeleteRows = false;
            this.dgvMemberList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMemberList.Location = new System.Drawing.Point(16, 98);
            this.dgvMemberList.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvMemberList.MultiSelect = false;
            this.dgvMemberList.Name = "dgvMemberList";
            this.dgvMemberList.ReadOnly = true;
            this.dgvMemberList.RowHeadersWidth = 51;
            this.dgvMemberList.RowTemplate.Height = 23;
            this.dgvMemberList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMemberList.Size = new System.Drawing.Size(1067, 312);
            this.dgvMemberList.TabIndex = 1;
            this.dgvMemberList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMemberList_CellClick);
            // 
            // gbEdit
            // 
            this.gbEdit.Controls.Add(this.cmbStatus);
            this.gbEdit.Controls.Add(this.lblStatus);
            this.gbEdit.Controls.Add(this.txtTotalPoints);
            this.gbEdit.Controls.Add(this.lblTotalPoints);
            this.gbEdit.Controls.Add(this.txtTotalConsume);
            this.gbEdit.Controls.Add(this.lblTotalConsume);
            this.gbEdit.Controls.Add(this.cmbLevel);
            this.gbEdit.Controls.Add(this.lblLevel);
            this.gbEdit.Controls.Add(this.txtAddress);
            this.gbEdit.Controls.Add(this.lblAddress);
            this.gbEdit.Controls.Add(this.txtPhone);
            this.gbEdit.Controls.Add(this.lblPhone);
            this.gbEdit.Controls.Add(this.txtMemberName);
            this.gbEdit.Controls.Add(this.lblMemberName);
            this.gbEdit.Controls.Add(this.txtMemberCardEdit);
            this.gbEdit.Controls.Add(this.lblMemberCardEdit);
            this.gbEdit.Location = new System.Drawing.Point(16, 418);
            this.gbEdit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbEdit.Name = "gbEdit";
            this.gbEdit.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbEdit.Size = new System.Drawing.Size(1067, 225);
            this.gbEdit.TabIndex = 2;
            this.gbEdit.TabStop = false;
            this.gbEdit.Text = "会员编辑";
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "正常",
            "注销"});
            this.cmbStatus.Location = new System.Drawing.Point(652, 150);
            this.cmbStatus.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(199, 23);
            this.cmbStatus.TabIndex = 15;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(560, 154);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(82, 15);
            this.lblStatus.TabIndex = 14;
            this.lblStatus.Text = "会员状态：";
            // 
            // txtTotalPoints
            // 
            this.txtTotalPoints.Location = new System.Drawing.Point(652, 112);
            this.txtTotalPoints.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTotalPoints.Name = "txtTotalPoints";
            this.txtTotalPoints.ReadOnly = true;
            this.txtTotalPoints.Size = new System.Drawing.Size(199, 25);
            this.txtTotalPoints.TabIndex = 13;
            // 
            // lblTotalPoints
            // 
            this.lblTotalPoints.AutoSize = true;
            this.lblTotalPoints.Location = new System.Drawing.Point(560, 116);
            this.lblTotalPoints.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalPoints.Name = "lblTotalPoints";
            this.lblTotalPoints.Size = new System.Drawing.Size(82, 15);
            this.lblTotalPoints.TabIndex = 12;
            this.lblTotalPoints.Text = "累计积分：";
            // 
            // txtTotalConsume
            // 
            this.txtTotalConsume.Location = new System.Drawing.Point(652, 75);
            this.txtTotalConsume.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTotalConsume.Name = "txtTotalConsume";
            this.txtTotalConsume.ReadOnly = true;
            this.txtTotalConsume.Size = new System.Drawing.Size(199, 25);
            this.txtTotalConsume.TabIndex = 11;
            // 
            // lblTotalConsume
            // 
            this.lblTotalConsume.AutoSize = true;
            this.lblTotalConsume.Location = new System.Drawing.Point(560, 79);
            this.lblTotalConsume.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalConsume.Name = "lblTotalConsume";
            this.lblTotalConsume.Size = new System.Drawing.Size(82, 15);
            this.lblTotalConsume.TabIndex = 10;
            this.lblTotalConsume.Text = "累计消费：";
            // 
            // cmbLevel
            // 
            this.cmbLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLevel.FormattingEnabled = true;
            this.cmbLevel.Location = new System.Drawing.Point(652, 38);
            this.cmbLevel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbLevel.Name = "cmbLevel";
            this.cmbLevel.Size = new System.Drawing.Size(199, 23);
            this.cmbLevel.TabIndex = 9;
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.Location = new System.Drawing.Point(560, 41);
            this.lblLevel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(82, 15);
            this.lblLevel.TabIndex = 8;
            this.lblLevel.Text = "会员等级：";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(119, 150);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(399, 62);
            this.txtAddress.TabIndex = 7;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(27, 154);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(82, 15);
            this.lblAddress.TabIndex = 6;
            this.lblAddress.Text = "会员地址：";
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(119, 112);
            this.txtPhone.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(399, 25);
            this.txtPhone.TabIndex = 5;
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(27, 116);
            this.lblPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(82, 15);
            this.lblPhone.TabIndex = 4;
            this.lblPhone.Text = "联系电话：";
            // 
            // txtMemberName
            // 
            this.txtMemberName.Location = new System.Drawing.Point(119, 75);
            this.txtMemberName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMemberName.Name = "txtMemberName";
            this.txtMemberName.Size = new System.Drawing.Size(399, 25);
            this.txtMemberName.TabIndex = 3;
            // 
            // lblMemberName
            // 
            this.lblMemberName.AutoSize = true;
            this.lblMemberName.Location = new System.Drawing.Point(27, 79);
            this.lblMemberName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMemberName.Name = "lblMemberName";
            this.lblMemberName.Size = new System.Drawing.Size(82, 15);
            this.lblMemberName.TabIndex = 2;
            this.lblMemberName.Text = "会员姓名：";
            // 
            // txtMemberCardEdit
            // 
            this.txtMemberCardEdit.Location = new System.Drawing.Point(119, 38);
            this.txtMemberCardEdit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMemberCardEdit.Name = "txtMemberCardEdit";
            this.txtMemberCardEdit.Size = new System.Drawing.Size(399, 25);
            this.txtMemberCardEdit.TabIndex = 1;
            // 
            // lblMemberCardEdit
            // 
            this.lblMemberCardEdit.AutoSize = true;
            this.lblMemberCardEdit.Location = new System.Drawing.Point(27, 41);
            this.lblMemberCardEdit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMemberCardEdit.Name = "lblMemberCardEdit";
            this.lblMemberCardEdit.Size = new System.Drawing.Size(82, 15);
            this.lblMemberCardEdit.TabIndex = 0;
            this.lblMemberCardEdit.Text = "会员卡号：";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(16, 650);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 29);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "新增";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(124, 650);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 29);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(232, 650);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 29);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "清空";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(340, 650);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 29);
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "删除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnExchange
            // 
            this.btnExchange.Location = new System.Drawing.Point(448, 650);
            this.btnExchange.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnExchange.Name = "btnExchange";
            this.btnExchange.Size = new System.Drawing.Size(100, 29);
            this.btnExchange.TabIndex = 7;
            this.btnExchange.Text = "积分兑换";
            this.btnExchange.UseVisualStyleBackColor = true;
            this.btnExchange.Click += new System.EventHandler(this.btnExchange_Click);
            // 
            // btnUpgrade
            // 
            this.btnUpgrade.Location = new System.Drawing.Point(556, 650);
            this.btnUpgrade.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnUpgrade.Name = "btnUpgrade";
            this.btnUpgrade.Size = new System.Drawing.Size(100, 29);
            this.btnUpgrade.TabIndex = 8;
            this.btnUpgrade.Text = "等级升级";
            this.btnUpgrade.UseVisualStyleBackColor = true;
            this.btnUpgrade.Click += new System.EventHandler(this.btnUpgrade_Click);
            // 
            // btnConsume
            // 
            this.btnConsume.Location = new System.Drawing.Point(664, 650);
            this.btnConsume.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnConsume.Name = "btnConsume";
            this.btnConsume.Size = new System.Drawing.Size(120, 29);
            this.btnConsume.TabIndex = 9;
            this.btnConsume.Text = "消费记录";
            this.btnConsume.UseVisualStyleBackColor = true;
            this.btnConsume.Click += new System.EventHandler(this.btnConsume_Click);
            // 
            // FrmMemberManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1099, 694);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.gbEdit);
            this.Controls.Add(this.dgvMemberList);
            this.Controls.Add(this.gbQuery);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnExchange);
            this.Controls.Add(this.btnUpgrade);
            this.Controls.Add(this.btnConsume);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmMemberManager";
            this.Text = "超市会员管理系统";
            this.Load += new System.EventHandler(this.FrmMemberManager_Load);
            this.gbQuery.ResumeLayout(false);
            this.gbQuery.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMemberList)).EndInit();
            this.gbEdit.ResumeLayout(false);
            this.gbEdit.PerformLayout();
            this.ResumeLayout(false);

        }

// 声明新增按钮变量
private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnExchange;
        private System.Windows.Forms.Button btnUpgrade;
        private System.Windows.Forms.Button btnConsume;
        

        #endregion

        private System.Windows.Forms.GroupBox gbQuery;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.TextBox txtMemberCard;
        private System.Windows.Forms.Label lblMemberCard;
        private System.Windows.Forms.DataGridView dgvMemberList;
        private System.Windows.Forms.GroupBox gbEdit;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtMemberName;
        private System.Windows.Forms.Label lblMemberName;
        private System.Windows.Forms.TextBox txtMemberCardEdit;
        private System.Windows.Forms.Label lblMemberCardEdit;
        private System.Windows.Forms.ComboBox cmbLevel;
        private System.Windows.Forms.Label lblLevel;
        private System.Windows.Forms.TextBox txtTotalPoints;
        private System.Windows.Forms.Label lblTotalPoints;
        private System.Windows.Forms.TextBox txtTotalConsume;
        private System.Windows.Forms.Label lblTotalConsume;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
    }
}