﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace SupermarketSalesSystem.Utils
{
    /// <summary>
    /// SQL Server数据库帮助类
    /// </summary>
    public class DbHelper
    {
        // 请替换为你的数据库连接字符串
        public static readonly string _connStr = "Data Source=LAPTOP-RMGPAU08\\SQLEXPRESS;Initial Catalog=SupermarketSalesDB;Integrated Security=True;Connect Timeout=10;";

        /// <summary>
        /// 执行查询，返回DataTable
        /// </summary>
        public static DataTable ExecuteQuery(string sql, SqlParameter[] parameters = null)
        {
            using (SqlConnection conn = new SqlConnection(_connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw new Exception("数据库查询出错：" + ex.Message);
                }
            }
        }

        /// <summary>
        /// 执行增删改操作，返回受影响行数
        /// </summary>
        public static int ExecuteNonQuery(string sql, SqlParameter[] parameters = null)
        {
            using (SqlConnection conn = new SqlConnection(_connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    return cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("数据库操作出错：" + ex.Message);
                }
            }
        }

        /// <summary>
        /// 执行查询，返回单个值
        /// </summary>
        public static object ExecuteScalar(string sql, SqlParameter[] parameters = null)
        {
            using (SqlConnection conn = new SqlConnection(_connStr))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    return cmd.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    throw new Exception("数据库查询出错：" + ex.Message);
                }
            }
        }
    }
}