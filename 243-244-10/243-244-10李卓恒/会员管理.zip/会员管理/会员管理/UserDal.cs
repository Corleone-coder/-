﻿using SupermarketSalesSystem.Models;
using SupermarketSalesSystem.Utils;
using System;
using System.Data;
using System.Data.SqlClient;

namespace SupermarketSalesSystem.DAL
{
    /// <summary>
    /// 用户数据访问类（登录验证）
    /// </summary>
    public class UserDal
    {
        /// <summary>
        /// 登录验证（用户名+密码）
        /// </summary>
        public SysUser Login(string userName, string password)
        {
            string sql = @"SELECT u.*, r.role_name 
                           FROM sys_user u
                           LEFT JOIN sys_role r ON u.role_id = r.role_id
                           WHERE u.user_name = @UserName AND u.password = @Password AND u.status = 1";
            SqlParameter[] parameters = new[]
            {
                new SqlParameter("@UserName", SqlDbType.VarChar, 50) { Value = userName },
                new SqlParameter("@Password", SqlDbType.VarChar, 64) { Value = password }
            };
            DataTable dt = DbHelper.ExecuteQuery(sql, parameters);
            if (dt.Rows.Count == 0) return null;

            DataRow row = dt.Rows[0];
            return new SysUser
            {
                UserId = row["user_id"].ToString(),
                UserName = row["user_name"].ToString(),
                Password = row["password"].ToString(),
                RealName = row["real_name"].ToString(),
                RoleId = row["role_id"].ToString(),
                RoleName = row["role_name"]?.ToString(),
                Phone = row["phone"]?.ToString(),
                Status = Convert.ToInt32(row["status"])
            };
        }
    }
}