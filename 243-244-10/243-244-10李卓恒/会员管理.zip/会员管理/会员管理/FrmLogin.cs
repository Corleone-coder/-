﻿using System;
using System.Windows.Forms;
using SupermarketSalesSystem.DAL;
using SupermarketSalesSystem.Models;

namespace SupermarketSalesSystem.UI
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 登录按钮点击事件
        /// </summary>
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string userName = txtUserName.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("请输入用户名和密码！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            UserDal userDal = new UserDal();
            SysUser user = userDal.Login(userName, password);
            if (user != null)
            {
                // 登录成功，保存当前用户信息，打开会员管理主窗体
                GlobalContext.CurrentUser = user;
                FrmMemberManager mainForm = new FrmMemberManager();
                mainForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("用户名或密码错误，或账号已禁用！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Clear();
                txtUserName.Focus();
            }
        }

        /// <summary>
        /// 取消按钮点击事件
        /// </summary>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }

    /// <summary>
    /// 全局上下文（保存当前登录用户）
    /// </summary>
    public static class GlobalContext
    {
        public static SysUser CurrentUser { get; set; }
    }
}
