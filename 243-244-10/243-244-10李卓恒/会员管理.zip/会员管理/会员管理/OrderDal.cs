﻿using System.Data;
using System.Data.SqlClient;
using SupermarketSalesSystem.Models;
using SupermarketSalesSystem.Utils;

namespace SupermarketSalesSystem.DAL
{
    /// <summary>
    /// 订单/消费记录数据访问类
    /// </summary>
    public class OrderDal
    {
        /// <summary>
        /// 根据会员ID查询消费记录
        /// </summary>
        public DataTable GetConsumeRecordsByMemberId(string memberId)
        {
            string sql = @"SELECT om.*, m.member_card, m.member_name, u.real_name AS cashier_name
                           FROM order_main om
                           LEFT JOIN member m ON om.member_id = m.member_id
                           LEFT JOIN sys_user u ON om.cashier_id = u.user_id
                           WHERE om.member_id = @MemberId AND om.order_status = 1 -- 只查已完成订单
                           ORDER BY om.order_time DESC";
            SqlParameter[] parameters = new[]
            {
                new SqlParameter("@MemberId", SqlDbType.VarChar, 32) { Value = memberId }
            };
            return DbHelper.ExecuteQuery(sql, parameters);
        }

        /// <summary>
        /// 根据会员卡号查询消费记录
        /// </summary>
        public DataTable GetConsumeRecordsByMemberCard(string memberCard)
        {
            string sql = @"SELECT om.*, m.member_card, m.member_name, u.real_name AS cashier_name
                           FROM order_main om
                           LEFT JOIN member m ON om.member_id = m.member_id
                           LEFT JOIN sys_user u ON om.cashier_id = u.user_id
                           WHERE m.member_card = @MemberCard AND om.order_status = 1
                           ORDER BY om.order_time DESC";
            SqlParameter[] parameters = new[]
            {
                new SqlParameter("@MemberCard", SqlDbType.VarChar, 50) { Value = memberCard }
            };
            return DbHelper.ExecuteQuery(sql, parameters);
        }
    }
}