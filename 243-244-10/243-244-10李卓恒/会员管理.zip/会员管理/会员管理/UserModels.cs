﻿using System;

namespace SupermarketSalesSystem.Models
{
    /// <summary>
    /// 系统用户实体（对应sys_user表）
    /// </summary>
    public class SysUser
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string RealName { get; set; }
        public string RoleId { get; set; }
        public string Phone { get; set; }
        public int Status { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime UpdateTime { get; set; }

        // 扩展：角色名称
        public string RoleName { get; set; }
    }
}