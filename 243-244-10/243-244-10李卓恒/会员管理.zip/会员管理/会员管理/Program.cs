﻿using System;
using System.Windows.Forms;

namespace SupermarketSalesSystem
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // 先打开登录窗体
            Application.Run(new UI.FrmLogin());
        }
    }
}