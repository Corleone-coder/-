﻿using SupermarketSalesSystem.DAL;
using SupermarketSalesSystem.Models;
using SupermarketSalesSystem.Utils;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SupermarketSalesSystem.UI
{
    public partial class FrmMemberManager : Form
    {
        private readonly MemberDal _memberDal = new MemberDal();
        private string _currentMemberId = null; // 当前选中的会员ID

        public FrmMemberManager()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 窗体加载事件
        /// </summary>
        private void FrmMemberManager_Load(object sender, EventArgs e)
        {
            // 加载会员等级下拉框
            LoadMemberLevels();
            // 加载会员列表
            LoadMemberList();
            // 默认选中正常状态
            cmbStatus.SelectedIndex = 0;
        }

        /// <summary>
        /// 加载会员等级到下拉框
        /// </summary>
        private void LoadMemberLevels()
        {
            DataTable dt = _memberDal.GetAllMemberLevels();
            cmbLevel.DataSource = dt;
            cmbLevel.DisplayMember = "level_name";
            cmbLevel.ValueMember = "level_id";
        }

        /// <summary>
        /// 加载会员列表到DataGridView
        /// </summary>
        private void LoadMemberList(string memberCard = "")
        {
            DataTable dt;
            if (string.IsNullOrEmpty(memberCard))
            {
                dt = _memberDal.GetAllMembers();
            }
            else
            {
                // 按卡号查询
                Member member = _memberDal.GetMemberByCard(memberCard);
                dt = new DataTable();
                if (member != null)
                {
                    dt.Columns.AddRange(new[]
                    {
                        new DataColumn("member_id"),
                        new DataColumn("member_card"),
                        new DataColumn("member_name"),
                        new DataColumn("phone"),
                        new DataColumn("level_name"),
                        new DataColumn("total_consume"),
                        new DataColumn("total_points"),
                        new DataColumn("StatusName")
                    });
                    DataRow row = dt.NewRow();
                    row["member_id"] = member.MemberId;
                    row["member_card"] = member.MemberCard;
                    row["member_name"] = member.MemberName;
                    row["phone"] = member.Phone;
                    row["level_name"] = member.LevelName;
                    row["total_consume"] = member.TotalConsume;
                    row["total_points"] = member.TotalPoints;
                    row["StatusName"] = member.StatusName;
                    dt.Rows.Add(row);
                }
            }

            dgvMemberList.DataSource = dt;
            // 设置列名
            SetDgvColumnNames();
        }

        /// <summary>
        /// 设置DataGridView列名
        /// </summary>
        private void SetDgvColumnNames()
        {
            if (dgvMemberList.Columns["member_card"] != null)
                dgvMemberList.Columns["member_card"].HeaderText = "会员卡号";
            if (dgvMemberList.Columns["member_name"] != null)
                dgvMemberList.Columns["member_name"].HeaderText = "会员姓名";
            if (dgvMemberList.Columns["phone"] != null)
                dgvMemberList.Columns["phone"].HeaderText = "联系电话";
            if (dgvMemberList.Columns["level_name"] != null)
                dgvMemberList.Columns["level_name"].HeaderText = "会员等级";
            if (dgvMemberList.Columns["total_consume"] != null)
                dgvMemberList.Columns["total_consume"].HeaderText = "累计消费";
            if (dgvMemberList.Columns["total_points"] != null)
                dgvMemberList.Columns["total_points"].HeaderText = "累计积分";
            if (dgvMemberList.Columns["StatusName"] != null)
                dgvMemberList.Columns["StatusName"].HeaderText = "会员状态";
            // 隐藏主键列
            if (dgvMemberList.Columns["member_id"] != null)
                dgvMemberList.Columns["member_id"].Visible = false;
        }

        /// <summary>
        /// 查询按钮点击事件
        /// </summary>
        private void btnQuery_Click(object sender, EventArgs e)
        {
            LoadMemberList(txtMemberCard.Text.Trim());
        }

        /// <summary>
        /// 选中会员行，加载到编辑区域
        /// </summary>
        private void dgvMemberList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvMemberList.Rows[e.RowIndex];
            _currentMemberId = row.Cells["member_id"].Value.ToString();

            // 加载数据到编辑框
            txtMemberCardEdit.Text = row.Cells["member_card"].Value.ToString();
            txtMemberName.Text = row.Cells["member_name"].Value.ToString();
            txtPhone.Text = row.Cells["phone"].Value?.ToString() ?? "";
            txtTotalConsume.Text = row.Cells["total_consume"].Value.ToString();
            txtTotalPoints.Text = row.Cells["total_points"].Value.ToString();

            // 会员等级（需要匹配Value）
            string levelName = row.Cells["level_name"].Value.ToString();
            for (int i = 0; i < cmbLevel.Items.Count; i++)
            {
                DataRowView drv = (DataRowView)cmbLevel.Items[i];
                if (drv["level_name"].ToString() == levelName)
                {
                    cmbLevel.SelectedIndex = i;
                    break;
                }
            }

            // 会员状态
            cmbStatus.Text = row.Cells["StatusName"].Value.ToString();

            // 查询完整地址
            Member member = _memberDal.GetMemberByCard(txtMemberCardEdit.Text);
            txtAddress.Text = member?.Address ?? "";
        }

        /// <summary>
        /// 新增按钮点击事件
        /// </summary>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            ClearEditControls();
            _currentMemberId = null;
            txtMemberCardEdit.Focus();
        }

        /// <summary>
        /// 保存按钮点击事件
        /// </summary>
        private void btnSave_Click(object sender, EventArgs e)
        {
            // 验证必填项
            if (string.IsNullOrEmpty(txtMemberCardEdit.Text.Trim()))
            {
                MessageBox.Show("请输入会员卡号！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrEmpty(txtMemberName.Text.Trim()))
            {
                MessageBox.Show("请输入会员姓名！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                Member member = new Member
                {
                    MemberCard = txtMemberCardEdit.Text.Trim(),
                    MemberName = txtMemberName.Text.Trim(),
                    Phone = txtPhone.Text.Trim(),
                    Address = txtAddress.Text.Trim(),
                    LevelId = cmbLevel.SelectedValue.ToString(),
                    TotalConsume = 0, // 新增时累计消费为0
                    TotalPoints = 0,   // 新增时积分为0
                    Status = cmbStatus.SelectedIndex == 0 ? 1 : 0
                };

                bool result;
                if (string.IsNullOrEmpty(_currentMemberId))
                {
                    // 新增会员
                    result = _memberDal.AddMember(member);
                }
                else
                {
                    // 修改会员
                    member.MemberId = _currentMemberId;
                    // 累计消费和积分从界面读取（实际项目中建议从数据库取，避免手动修改）
                    member.TotalConsume = decimal.TryParse(txtTotalConsume.Text, out decimal consume) ? consume : 0;
                    member.TotalPoints = int.TryParse(txtTotalPoints.Text, out int points) ? points : 0;
                    result = _memberDal.UpdateMember(member);
                }

                if (result)
                {
                    MessageBox.Show(string.IsNullOrEmpty(_currentMemberId) ? "新增会员成功！" : "修改会员成功！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadMemberList();
                    ClearEditControls();
                }
                else
                {
                    MessageBox.Show("操作失败，请检查数据！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("保存失败：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 清空编辑框
        /// </summary>
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearEditControls();
        }

        /// <summary>
        /// 清空编辑区域控件
        /// </summary>
        private void ClearEditControls()
        {
            txtMemberCardEdit.Clear();
            txtMemberName.Clear();
            txtPhone.Clear();
            txtAddress.Clear();
            txtTotalConsume.Clear();
            txtTotalPoints.Clear();
            cmbLevel.SelectedIndex = 0;
            cmbStatus.SelectedIndex = 0;
            _currentMemberId = null;
        }

        /// <summary>
        /// 删除会员（逻辑删除）
        /// </summary>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_currentMemberId))
            {
                MessageBox.Show("请先选中会员！当前_memberId为空", "提示");
                return;
            }

            DialogResult result = MessageBox.Show($"确认注销会员ID：{_currentMemberId}吗？", "确认", MessageBoxButtons.YesNo);
            if (result != DialogResult.Yes) return;

            try
            {
                bool success = _memberDal.DeleteMember(_currentMemberId);
                if (success)
                {
                    MessageBox.Show("注销成功！");
                    LoadMemberList(""); // 刷新全部会员
                }
                else
                {
                    // 1. 拆分多行字符串，用"+"拼接
                    string sql = "UPDATE member SET status=0 WHERE member_id=@id";
                    // 2. 正确构造SqlParameter数组
                    SqlParameter[] parameters = new[]
                    {
        new SqlParameter("@id", _currentMemberId)
    };
                    // 3. 执行SQL并获取受影响行数
                    int affectedRows = DbHelper.ExecuteNonQuery(sql, parameters);
                    // 4. 显示提示
                    MessageBox.Show($"注销失败！受影响行数：{affectedRows}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("删除出错：" + ex.Message);
            }
        }

        /// <summary>
        /// 积分兑换
        /// </summary>
        private void btnExchange_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_currentMemberId))
            {
                MessageBox.Show("请先选中会员！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 弹出输入框，输入兑换积分
            string input = Microsoft.VisualBasic.Interaction.InputBox("请输入兑换积分（100积分=1元）：", "积分兑换", "100");
            if (!int.TryParse(input, out int exchangePoints) || exchangePoints <= 0 || exchangePoints % 100 != 0)
            {
                MessageBox.Show("请输入有效的兑换积分（正整数，且为100的倍数）！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal exchangeAmount = exchangePoints / 100m; // 100积分=1元
            bool success = _memberDal.ExchangePoints(_currentMemberId, exchangePoints, exchangeAmount);
            if (success)
            {
                MessageBox.Show($"积分兑换成功！兑换{exchangePoints}积分，抵扣{exchangeAmount}元", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadMemberList(txtMemberCard.Text.Trim()); // 刷新列表
            }
            else
            {
                MessageBox.Show("积分兑换失败（可能积分不足）！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 等级升级
        /// </summary>
        private void btnUpgrade_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_currentMemberId))
            {
                MessageBox.Show("请先选中会员！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool success = _memberDal.AutoUpgradeMemberLevel(_currentMemberId);
            if (success)
            {
                MessageBox.Show("会员等级升级成功！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadMemberList(txtMemberCard.Text.Trim()); // 刷新列表
            }
            else
            {
                MessageBox.Show("当前会员已为最高等级，无需升级！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        /// 打开消费记录查询窗体
        /// </summary>
        private void btnConsume_Click(object sender, EventArgs e)
        {
            FrmMemberConsume consumeForm = new FrmMemberConsume();
            // 传递当前选中会员卡号
            if (!string.IsNullOrEmpty(txtMemberCardEdit.Text))
            {
                consumeForm.txtMemberCard.Text = txtMemberCardEdit.Text;
            }
            consumeForm.ShowDialog();
        }

        private void gbQuery_Enter(object sender, EventArgs e)
        {

        }
    }
}