﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using SupermarketSalesSystem.Models;
using SupermarketSalesSystem.Utils;

namespace SupermarketSalesSystem.DAL
{
    /// <summary>
    /// 会员数据访问类
    /// </summary>
    public class MemberDal
    {
        /// <summary>
        /// 获取所有会员列表
        /// </summary>
        public DataTable GetAllMembers()
        {
            
            string sql = @"SELECT m.*, ml.level_name 
                   FROM member m
                   LEFT JOIN member_level ml ON m.level_id = ml.level_id
                   WHERE m.status = 1  -- 仅显示未注销（status=1）的会员
                   ORDER BY m.create_time DESC";
            return DbHelper.ExecuteQuery(sql);
        
        }

        /// <summary>
        /// 根据会员卡号查询会员
        /// </summary>
        public Member GetMemberByCard(string memberCard)
        {
            string sql = @"SELECT m.*, ml.level_name 
                           FROM member m
                           LEFT JOIN member_level ml ON m.level_id = ml.level_id
                           WHERE m.member_card = @MemberCard";
            SqlParameter[] parameters = new[]
            {
                new SqlParameter("@MemberCard", SqlDbType.VarChar, 50) { Value = memberCard }
            };
            DataTable dt = DbHelper.ExecuteQuery(sql, parameters);
            if (dt.Rows.Count == 0) return null;

            DataRow row = dt.Rows[0];
            return new Member
            {
                MemberId = row["member_id"].ToString(),
                MemberCard = row["member_card"].ToString(),
                MemberName = row["member_name"].ToString(),
                Phone = row["phone"]?.ToString(),
                Address = row["address"]?.ToString(),
                LevelId = row["level_id"].ToString(),
                LevelName = row["level_name"]?.ToString(),
                TotalConsume = Convert.ToDecimal(row["total_consume"]),
                TotalPoints = Convert.ToInt32(row["total_points"]),
                Status = Convert.ToInt32(row["status"]),
                CreateTime = Convert.ToDateTime(row["create_time"]),
                UpdateTime = Convert.ToDateTime(row["update_time"])
            };
        }

        /// <summary>
        /// 新增会员
        /// </summary>
        public bool AddMember(Member member)
        {
            try
            {
                string sql = @"INSERT INTO member 
                               (member_id, member_card, member_name, phone, address, level_id, total_consume, total_points, status, create_time, update_time)
                               VALUES (@MemberId, @MemberCard, @MemberName, @Phone, @Address, @LevelId, @TotalConsume, @TotalPoints, @Status, @CreateTime, @UpdateTime)";

                SqlParameter[] parameters = new[]
                {
                    new SqlParameter("@MemberId", SqlDbType.VarChar, 32) { Value = Guid.NewGuid().ToString("N") },
                    new SqlParameter("@MemberCard", SqlDbType.VarChar, 50) { Value = member.MemberCard },
                    new SqlParameter("@MemberName", SqlDbType.VarChar, 50) { Value = member.MemberName },
                    // Phone参数：如果member.Phone是null，就赋值DBNull.Value，否则赋值实际值
new SqlParameter("@Phone", SqlDbType.VarChar, 20) { Value = member.Phone == null ? DBNull.Value : (object)member.Phone },

// Address参数：同理
new SqlParameter("@Address", SqlDbType.VarChar, 200) { Value = member.Address == null ? DBNull.Value : (object)member.Address },
                    new SqlParameter("@LevelId", SqlDbType.VarChar, 32) { Value = member.LevelId },
                    new SqlParameter("@TotalConsume", SqlDbType.Decimal) { Value = member.TotalConsume },
                    new SqlParameter("@TotalPoints", SqlDbType.Int) { Value = member.TotalPoints },
                    new SqlParameter("@Status", SqlDbType.TinyInt) { Value = member.Status },
                    new SqlParameter("@CreateTime", SqlDbType.DateTime) { Value = DateTime.Now },
                    new SqlParameter("@UpdateTime", SqlDbType.DateTime) { Value = DateTime.Now }
                };

                int rows = DbHelper.ExecuteNonQuery(sql, parameters);
                return rows > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 修改会员信息
        /// </summary>
        public bool UpdateMember(Member member)
        {
            try
            {
                string sql = @"UPDATE member 
                               SET member_name = @MemberName, phone = @Phone, address = @Address, 
                                   level_id = @LevelId, status = @Status, update_time = @UpdateTime
                               WHERE member_id = @MemberId";

                SqlParameter[] parameters = new[]
                {
                    new SqlParameter("@MemberName", SqlDbType.VarChar, 50) { Value = member.MemberName },
                   // Phone参数：如果member.Phone是null，就赋值DBNull.Value，否则赋值实际值
new SqlParameter("@Phone", SqlDbType.VarChar, 20) { Value = member.Phone == null ? DBNull.Value : (object)member.Phone },

// Address参数：同理
new SqlParameter("@Address", SqlDbType.VarChar, 200) { Value = member.Address == null ? DBNull.Value : (object)member.Address },
                    new SqlParameter("@LevelId", SqlDbType.VarChar, 32) { Value = member.LevelId },
                    new SqlParameter("@Status", SqlDbType.TinyInt) { Value = member.Status },
                    new SqlParameter("@UpdateTime", SqlDbType.DateTime) { Value = DateTime.Now },
                    new SqlParameter("@MemberId", SqlDbType.VarChar, 32) { Value = member.MemberId }
                };

                int rows = DbHelper.ExecuteNonQuery(sql, parameters);
                return rows > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 获取所有会员等级
        /// </summary>
        public DataTable GetAllMemberLevels()
        {
            string sql = "SELECT * FROM member_level ORDER BY upgrade_consume ASC";
            return DbHelper.ExecuteQuery(sql);
        }

        /// <summary>
        /// 逻辑删除会员（修改status为0）
        /// </summary>
        public bool DeleteMember(string memberId)
        {
            try
            {
                string sql = "DELETE FROM member WHERE member_id = @MemberId;";
                SqlParameter[] parameters = new[]
                {
                    new SqlParameter("@UpdateTime", SqlDbType.DateTime) { Value = DateTime.Now },
                    new SqlParameter("@MemberId", SqlDbType.VarChar, 32) { Value = memberId }
                };
                int rows = DbHelper.ExecuteNonQuery(sql, parameters);
                return rows > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 积分兑换（扣减积分，可扩展生成兑换记录）
        /// </summary>
        public bool ExchangePoints(string memberId, int exchangePoints, decimal exchangeAmount)
        {
            // 使用事务保证数据一致性
            using (SqlConnection conn = new SqlConnection(DbHelper._connStr))
            {
                try
                {
                    conn.Open();
                    SqlTransaction tran = conn.BeginTransaction();

                    // 1. 查询当前积分
                    string sqlCheck = "SELECT total_points FROM member WHERE member_id = @MemberId";
                    SqlCommand cmdCheck = new SqlCommand(sqlCheck, conn, tran);
                    cmdCheck.Parameters.Add(new SqlParameter("@MemberId", memberId));
                    int currentPoints = Convert.ToInt32(cmdCheck.ExecuteScalar());

                    if (currentPoints < exchangePoints)
                    {
                        tran.Rollback();
                        return false; // 积分不足
                    }

                    // 2. 扣减积分
                    string sqlUpdate = "UPDATE member SET total_points = total_points - @ExchangePoints, update_time = @UpdateTime WHERE member_id = @MemberId";
                    SqlCommand cmdUpdate = new SqlCommand(sqlUpdate, conn, tran);
                    cmdUpdate.Parameters.Add(new SqlParameter("@ExchangePoints", exchangePoints));
                    cmdUpdate.Parameters.Add(new SqlParameter("@UpdateTime", DateTime.Now));
                    cmdUpdate.Parameters.Add(new SqlParameter("@MemberId", memberId));
                    cmdUpdate.ExecuteNonQuery();

                    // （可选）3. 插入积分兑换记录（需新增表，这里省略，可根据需求扩展）

                    tran.Commit();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// 自动判断会员等级升级
        /// </summary>
        public bool AutoUpgradeMemberLevel(string memberId)
        {
            try
            {
                // 1. 查询会员当前累计消费、积分、等级
                string sqlMember = @"SELECT m.total_consume, m.total_points, m.level_id, 
                                        ml.upgrade_points, ml.upgrade_consume
                                     FROM member m
                                     LEFT JOIN member_level ml ON m.level_id = ml.level_id
                                     WHERE m.member_id = @MemberId";
                SqlParameter[] paramMember = new[] { new SqlParameter("@MemberId", memberId) };
                DataTable dtMember = DbHelper.ExecuteQuery(sqlMember, paramMember);
                if (dtMember.Rows.Count == 0) return false;

                DataRow row = dtMember.Rows[0];
                decimal totalConsume = Convert.ToDecimal(row["total_consume"]);
                int totalPoints = Convert.ToInt32(row["total_points"]);
                string currentLevelId = row["level_id"].ToString();
                int currentUpgradePoints = Convert.ToInt32(row["upgrade_points"]);
                decimal currentUpgradeConsume = Convert.ToDecimal(row["upgrade_consume"]);

                // 2. 查询更高等级的会员等级（满足消费/积分条件）
                string sqlLevel = @"SELECT TOP 1 level_id FROM member_level 
                                    WHERE (upgrade_points <= @TotalPoints OR upgrade_consume <= @TotalConsume)
                                    AND level_id != @CurrentLevelId
                                    ORDER BY upgrade_consume DESC";
                SqlParameter[] paramLevel = new[]
                {
                    new SqlParameter("@TotalPoints", totalPoints),
                    new SqlParameter("@TotalConsume", totalConsume),
                    new SqlParameter("@CurrentLevelId", currentLevelId)
                };
                object newLevelId = DbHelper.ExecuteScalar(sqlLevel, paramLevel);
                if (newLevelId == DBNull.Value || newLevelId == null) return false;

                // 3. 升级会员等级
                string sqlUpdate = "UPDATE member SET level_id = @NewLevelId, update_time = @UpdateTime WHERE member_id = @MemberId";
                SqlParameter[] paramUpdate = new[]
                {
                    new SqlParameter("@NewLevelId", newLevelId),
                    new SqlParameter("@UpdateTime", DateTime.Now),
                    new SqlParameter("@MemberId", memberId)
                };
                int rows = DbHelper.ExecuteNonQuery(sqlUpdate, paramUpdate);
                return rows > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 消费后更新会员累计消费和积分（1元=1积分）
        /// </summary>
        public bool UpdateMemberConsumeAndPoints(string memberId, decimal consumeAmount)
        {
            try
            {
                int addPoints = Convert.ToInt32(consumeAmount); // 1元=1积分
                string sql = @"UPDATE member 
                               SET total_consume = total_consume + @ConsumeAmount,
                                   total_points = total_points + @AddPoints,
                                   update_time = @UpdateTime
                               WHERE member_id = @MemberId";
                SqlParameter[] parameters = new[]
                {
                    new SqlParameter("@ConsumeAmount", consumeAmount),
                    new SqlParameter("@AddPoints", addPoints),
                    new SqlParameter("@UpdateTime", DateTime.Now),
                    new SqlParameter("@MemberId", memberId)
                };
                int rows = DbHelper.ExecuteNonQuery(sql, parameters);
                // 更新后自动判断等级升级
                if (rows > 0)
                {
                    AutoUpgradeMemberLevel(memberId);
                }
                return rows > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
